
<!-- /* nav for the home page */ -->
<nav>
            <!-- <div class="logo"><h1>logo</h1></div>  -->
            <div class="openMenu"><i class="fa fa-bars"></i></div>
            <ul class="mainMenu">
                <li><a id="home" href="index.php">Home</a></li>
                <div class="dropdown">
                    <button class="dropbtn">PLANETS</button>
                    <div class="dropdown-content">
                    <a href="asset/subpages/sun.php">Sun</a>
                    <a href="asset/subpages/mercury.php">Mercury</a>
                    <a href="asset/subpages/venus.php">Venus</a>
                    <a href="asset/subpages/earth.php">Earth</a>
                    <a href="asset/subpages/mars.php">Mars</a>
                    <a href="asset/subpages/jupiter.php">Jupiter</a>
                    <a href="asset/subpages/saturn.php">Saturn</a>
                    <a href="asset/subpages/uranus.php">Uranus</a>
                    <a href="asset/subpages/neptune.php">Neptune</a>
                 
                    </div>
                </div>
                <div class="closeMenu"><i class="fa fa-times"></i></div>
                <!-- <span class="icons">
                    <i class="fab fa-facebook"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-github"></i>
                </span> -->
            </ul>
        </nav>
