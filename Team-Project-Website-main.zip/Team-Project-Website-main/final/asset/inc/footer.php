<footer>
    <h2>Sources</h2>
    <p>
    <a 
        href="https://en.wikipedia.org/wiki/Sun"> Sun Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Mercury"> Mercury Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Venus"> Venus Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Earth"> Earth Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Mars"> Mars Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Jupiter"> Jupiter Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Saturn"> Saturn Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Neptune"> Neputne Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Uranus"> Uranus Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Moon"> Moon Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Thorne–Żytkow_object"> Thorne–Żytkow Wiki </a>
        &#11044;
        <a href="https://en.wikipedia.org/wiki/Lenticular_galaxy"> Lenticular_galaxy Wiki </a>
    </p>
</footer>
