    <section id = "wormhole">
            <h3>Do you dare enter the wormhole?</h3>
    </section>
<script src="../js/wormhole.js"></script>