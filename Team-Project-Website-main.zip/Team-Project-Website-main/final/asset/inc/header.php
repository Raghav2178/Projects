<header>
<h1>Solar System</h1>
<h2 id="planet-select">select a planet</h2>
</header>